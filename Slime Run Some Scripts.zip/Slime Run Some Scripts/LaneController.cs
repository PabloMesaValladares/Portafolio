using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaneController : MonoBehaviour
{
    private MovementBehavior _mvb;

    public float speed;
    private float savedspeed;

    public float timer;
    private float InsideTimer;

    private Vector3 dir;

    // Start is called before the first frame update
    void Awake()
    {
        _mvb = GetComponent<MovementBehavior>();

        _mvb.Init(speed);

        dir = Vector3.back;

        savedspeed = speed;

    }

    private void OnEnable()
    {
        TimeStop.OnStopTime += StopMovement;
        PlayerController.Dead += StopMovement;
        TimeStop.TimeNormal += ResetSpeed;
    }

    private void OnDisable()
    {
        TimeStop.OnStopTime -= StopMovement;
        PlayerController.Dead -= StopMovement;
        TimeStop.TimeNormal -= ResetSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        
        if (InsideTimer <= 0)
        {
            InsideTimer = 0;
            _mvb.Move(speed, dir);
        }
        else if(InsideTimer > 0)
        {
            _mvb.Move(-speed * 2, dir);
            InsideTimer -= 1 * Time.deltaTime;
        }
    }

    public void GoBack()
    {
        InsideTimer = timer;
    }

    public void SlowSpeed()
    {
        speed = speed / 2;
    }

    public void FastSpeed()
    {
        speed = speed * 2;
    }

    public void StopMovement(int i)
    {
        speed = 0;
    }

    public void ResetSpeed()
    {
        speed = savedspeed;
    }
}

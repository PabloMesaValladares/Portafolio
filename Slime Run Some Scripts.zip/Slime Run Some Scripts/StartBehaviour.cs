using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartBehaviour : MonoBehaviour
{
    public float timer;
    private int letsgo;

    [SerializeField]
    private GameObject three, two, one, go;

    // Start is called before the first frame update
    void Start()
    {
        SoundManager.Instance.StopSounds();
        SoundManager.Instance.PlayeSound("MusicLevel", true);
        GetComponent<LaneController>().StopMovement(0);
        letsgo = 4;
    }

    // Update is called once per frame
    void Update()
    {
        if (letsgo == 4)
        {
            timer -= 1 * Time.deltaTime;
            three.SetActive(true);
        }
        else if (letsgo == 3)
        {
            timer -= 1 * Time.deltaTime;
            three.SetActive(false);
            two.SetActive(true);
        }
        else if (letsgo == 2)
        {
            timer -= 1 * Time.deltaTime;
            two.SetActive(false);
            one.SetActive(true);
        }
        else if(letsgo == 1)
        {
            timer -= 1 * Time.deltaTime;
            one.SetActive(false);
            go.SetActive(true);
        }
        else if(letsgo == 0)
        {
            go.SetActive(false);
            GetComponent<LaneController>().ResetSpeed();
            GetComponent<StartBehaviour>().enabled = false;
        }

        if(timer <= 0)
        {
            timer = 1;
            letsgo--;
        }
    }
}

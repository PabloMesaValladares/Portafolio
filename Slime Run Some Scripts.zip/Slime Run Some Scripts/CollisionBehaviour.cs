using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class CollisionBehaviour : MonoBehaviour
{
    public int damage;
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.TryGetComponent<HealthBehaviour>(out HealthBehaviour _hb))
        {
            _hb.Hurt(damage);
        }

    }
}

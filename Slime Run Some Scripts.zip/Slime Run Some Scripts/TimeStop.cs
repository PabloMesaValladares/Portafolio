using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System;

public class TimeStop : MonoBehaviour
{
    private Animator _anim;
    public Slider TimeBar;

    public float timer;
    public float MaxRecharge;
    [SerializeField]
    private float InsideTimer, Recharge;

    bool stoped;
    public GameObject MainLane;

    public UnityEvent CanvasStopEffect;
    public UnityEvent CanvasNormalAgain;

    public delegate void STOPTIME();
    public static STOPTIME Stoped;

    public delegate void TIMEGOAGAIN();
    public static TIMEGOAGAIN TimeNormal;

    public static event Action<int> OnStopTime = delegate { };

    // Start is called before the first frame update
    void Start()
    {
        Recharge = 0;
        _anim = GetComponent<Animator>();
        stoped = false;
        InsideTimer = -2;
    }

    // Update is called once per frame
    void Update()
    {
        if (Recharge >= MaxRecharge && Input.GetKeyDown(KeyCode.Space))
        {
            SoundManager.Instance.PlayeSound("ZaWardo", false);
            CanvasStopEffect.Invoke();
            stoped = true;
            _anim.SetInteger("State", 0);
            transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
            OnStopTime.Invoke(0);
            Recharge = 0;
            InsideTimer = timer;
        }
        if (stoped)
        {
            if (InsideTimer > 0)
            {
                gameObject.layer = LayerMask.NameToLayer("OtherSpace");
                MainLane.GetComponent<LaneController>().StopMovement(0);
                gameObject.GetComponent<GodModeBehaviour>().enabled = false;
                InsideTimer -= 1 * Time.deltaTime;
            }
            else if (InsideTimer <= 0)
            {
                CanvasNormalAgain.Invoke();
                TimeNormal();
                stoped = false;
                InsideTimer = -2;
                gameObject.layer = LayerMask.NameToLayer("Player");
                MainLane.GetComponent<LaneController>().ResetSpeed();
                gameObject.GetComponent<GodModeBehaviour>().enabled = true;
            }
        }

        TimeBar.value = Recharge / MaxRecharge;
    }

    public void Recharing()
    {
        Recharge++;
    }
}

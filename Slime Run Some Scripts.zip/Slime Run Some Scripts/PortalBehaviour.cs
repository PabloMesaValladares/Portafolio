using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalBehaviour : MonoBehaviour
{
    public Transform Portal;
    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.TryGetComponent<PlayerController>(out PlayerController _pl))
        {
            SoundManager.Instance.PlayeSound("Portal", false);
            collision.gameObject.transform.position = Portal.transform.position;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class PlayerController : MonoBehaviour
{
    private Animator _anim;
    private MovementBehavior _mvb;

    public float speed, rotationSpeed;

    public float timer;
    private float InsideTimer;
    private bool Round;

    public static event Action<int> Dead = delegate { };

    // Start is called before the first frame update
    void Awake()
    {
        _anim = GetComponent<Animator>();
        _mvb = GetComponent<MovementBehavior>();

        GetComponent<TimeStop>().enabled = true;

        _mvb.Init(speed);
        _anim.SetInteger("State", 0);
    }

    // Update is called once per frame
    void Update()
    {
        if(Round == false)
        {
            //ir a la derecha o la izquierda
            if (Input.GetKey(KeyCode.A))
            {
                _mvb.Move3D(gameObject, Vector3.left, speed);

            }
            if (Input.GetKey(KeyCode.D))
            {
                _mvb.Move3D(gameObject, Vector3.right, speed);
            }
        }
        else
        {
            _mvb.Rotate3D(gameObject, -speed, rotationSpeed);
            //Girar cuando chocas con el Unicornio
            if (InsideTimer <= 0)
            {
                _anim.SetInteger("State", 0);
                Round = false;
                InsideTimer = 0;
                transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
                GetComponent<TimeStop>().enabled = true;
            }
            else if (InsideTimer > 0)
            {
                InsideTimer -= 1 * Time.deltaTime;
            }
        }
    }

    public void TurnAround()
    {
        SoundManager.Instance.PlayeSound("HitSound", false);
        _anim.SetInteger("State", 1);
        Round = true;
        InsideTimer = timer;
        GetComponent<TimeStop>().enabled = false;
    }

    public void Died()
    {
        transform.rotation = new Quaternion(transform.rotation.x, 0, transform.rotation.z, transform.rotation.w);
        Round = false;
        Dead.Invoke(0);
        SoundManager.Instance.PlayeSound("HitSound", false);
        _anim.SetInteger("State", 3);
        _mvb.Move3D(gameObject, Vector3.back, speed);
    }

    public void Winner()
    {
        SoundManager.Instance.StopSounds();
        SoundManager.Instance.PlayeSound("WinSound", false);
        SoundManager.Instance.PlayeSound("WinMusic", true);
        transform.rotation = new Quaternion(transform.rotation.x, 90, transform.rotation.z, transform.rotation.w);
        GetComponent<TimeStop>().enabled = false;
        speed = 0;
        GetComponent<HealthBehaviour>().enabled = false;
    }

    public void Loser()
    {
        SoundManager.Instance.StopSounds();
        SoundManager.Instance.PlayeSound("LoseSound", false);
        SoundManager.Instance.PlayeSound("LoseMusic", true);
        speed = 0;
        _anim.SetInteger("State", 1);
        GetComponent<TimeStop>().enabled = false;
        GetComponent<HealthBehaviour>().enabled = false;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GodModeBehaviour : MonoBehaviour
{
    private bool Inmortal;
    public GameObject Follower;
    public GameObject playerEffect;
    public GameObject LoadManager;
    public GameObject MainLane;

    [SerializeField]
    private List<GameObject> followersList;
    private int i;

    private void Start()
    {
        Inmortal = false;
        i = 0;
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H) && Inmortal == false)
        {
            Inmortal = true;
            gameObject.layer = LayerMask.NameToLayer("God");
            SoundManager.Instance.StopSounds();
            SoundManager.Instance.PlayeSound("GodMode", true);
            GetComponent<HealthBehaviour>().enabled = false;
            playerEffect.SetActive(true);
        }
        else if (Input.GetKeyDown(KeyCode.H) && Inmortal == true)
        {
            Inmortal = false;
            gameObject.layer = LayerMask.NameToLayer("Player");
            SoundManager.Instance.StopSounds();
            SoundManager.Instance.PlayeSound("MusicLevel", true);
            GetComponent<HealthBehaviour>().enabled = true;
            playerEffect.SetActive(false);
        }

        if(Input.GetKeyDown(KeyCode.F))
        {
            followersList.Add(Instantiate(Follower, transform.position, Quaternion.identity));
            i++;
        }
        if(Input.GetKeyDown(KeyCode.G))
        {
            followersList[0].GetComponent<FollowersBehaviour>().Died();
            followersList[0].GetComponent<followerDeath>().Ded();
            followersList.RemoveAt(0);
        }
        if (Input.GetKeyDown(KeyCode.J))
        {
            LoadManager.GetComponent<LoadingBehaviour>().LoadScene(7);
            MainLane.GetComponent<LaneController>().StopMovement(0);

        }
        if (Input.GetKeyDown(KeyCode.K))
        {
            LoadManager.GetComponent<LoadingBehaviour>().LoadScene(8);
            MainLane.GetComponent<LaneController>().StopMovement(0);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            LoadManager.GetComponent<LoadingBehaviour>().LoadScene(9);
            MainLane.GetComponent<LaneController>().StopMovement(0);
        }
    }
}

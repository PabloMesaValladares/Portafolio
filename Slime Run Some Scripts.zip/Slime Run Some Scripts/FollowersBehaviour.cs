using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class FollowersBehaviour : MonoBehaviour
{
    private MovementBehavior _mvb;
    private Animator _anim;
    public UnityEvent FollowerActivation, DisableFollowing;

    [SerializeField]
    private bool FollowPlayer, FollowPlayerAgain;
    public float speed, speedToo, speedAdd, speedOff;
    public GameObject player;
    [SerializeField]
    private int numFoll, Row;
    // Start is called before the first frame update
    void Awake()
    {
        FollowPlayer = false;
        _mvb = GetComponent<MovementBehavior>();
        _anim = GetComponent<Animator>();
        _anim.SetInteger("State", 1);
    }
    // Update is called once per frame
    void Update()
    {
        if(FollowPlayer == true)
        {
            _mvb.FollowingMove(player.transform.position, speed);
            Vector3 newDir = gameObject.transform.position + Vector3.back;
            _mvb.MoveV3(newDir, speedToo);
        }
    }

    private void OnEnable()
    {
        TimeStop.Stoped += StopMovement;
        TimeStop.TimeNormal += StartFollowingAgain;
        followerDeath.sendInfo += ChangeSpeedAgain;
    }
    private void OnDisable()
    {
        TimeStop.Stoped -= StopMovement;
        TimeStop.TimeNormal -= StartFollowingAgain;
        followerDeath.sendInfo -= ChangeSpeedAgain;
    }
    public void StartFollowing()
    {
        SoundManager.Instance.PlayeSound("PickSlime", false);
        FollowPlayer = true;
        _anim.SetInteger("State", 0);
    }
    public void StartFollowingAgain()
    {
        if(FollowPlayerAgain == true)
        {
            FollowPlayer = true;
            _anim.SetInteger("State", 0);
        }
    }

    public void StopMovement()
    {
        if(FollowPlayer == true)
        {
            _anim.SetInteger("State", 1);
            FollowPlayer = false;
            FollowPlayerAgain = true;        
        }
    }
    public void ChangeSpeedAgain(int counter, int F) //Recalcular la velocidad de los followers, si en su misma fila se ha muerto alguno y avisar al manager
    {
        if(counter == Row && F < numFoll)
        {
            //Debug.Log(counter + " + " + Row);
            //Debug.Log("AAAAAAAAAAAAAAAAAAh");
            numFoll -= (F + 1);
            speedToo = 1;
            speedToo = speedToo * (speedAdd * numFoll);
            speed = speed + (speedOff * numFoll);
            GetComponent<followerDeath>().setBoth(numFoll, Row);
        }
    }

    private void OnTriggerEnter(Collider other) //Avisa al Manager para la asignacion inicial de la fila que le toca y velocidad 
    {
        if(other.GetComponent<PlayerController>())
        {
            Row = other.GetComponent<FollowerManager>().ReturnCounter();
            numFoll = other.GetComponent<FollowerManager>().ReturnFollowers(Row);
            player = other.GetComponent<FollowerManager>().GivePos();
            gameObject.transform.SetParent(player.transform);
            speedAdd = other.GetComponent<FollowerManager>().SpeedIncrease;
            speedOff = other.GetComponent<FollowerManager>().SpeedDecrease;
            speedToo = 1;
            FollowPlayer = true;
            speedToo = speedToo * (speedAdd * numFoll);
            speed = speed + (speedOff * numFoll );
            GetComponent<followerDeath>().setBoth(numFoll, Row);
            StartFollowing();
            gameObject.layer = LayerMask.NameToLayer("Folloing");
            GetComponent<BoxCollider>().isTrigger = false;
        }
    }

    public void Died()
    {
        SoundManager.Instance.PlayeSound("HitSound", false);
        _anim.SetInteger("State", 3);
        _mvb.Move3D(gameObject, Vector3.back, speed);
        FollowPlayer = false;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class FollowerManager : MonoBehaviour
{
    public float SpeedIncrease, SpeedDecrease;
    public GameObject[] Pos;

    public UnityEvent Rechargenow, SendFollowers;


    public int[] followers;
    public int counterside;
    // Start is called before the first frame update
    void Start()
    {
        counterside = 0;
        followers = new int[Pos.Length];
    }

    private void OnEnable()
    {
        followerDeath.sendInfo += ChangeSpeedAgain;
    }
    private void OnDisable()
    {
        followerDeath.sendInfo -= ChangeSpeedAgain;
    }
    public int ReturnFollowers(int i)
    {
        return followers[i];
    }

    public int ReturnCounter()
    {
        return counterside;
    }

    public void AddFollowers(int i)
    {
        followers[i]++;
        Rechargenow.Invoke();
        SendFollowers.Invoke();
    }

    public void OffFollowers(int i)
    {
        followers[i]--;
    }

    public void ChangeSpeedAgain(int counter, int F) //  Reduce la cantidad de followers que hay en una linia, para poder recalcular la velocidad de los followers.
    {
        followers[counter]--;
        counterside = counter;
    }

    public GameObject GivePos() //Da las posiciones a los followers
    {
        AddFollowers(counterside);
        GameObject currentPos = Pos[counterside];
        if (counterside < 4)
            counterside++;
        else
            counterside = 0;
        return currentPos;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public class ProfileMemory : MonoBehaviour
{
    static StreamWriter dataLog;
    static StreamWriter timeLog;
    private long memoryReserved;

    private void Awake()
    {
        dataLog = new StreamWriter("Memory.csv");
        timeLog = new StreamWriter("Timing.csv");

        DontDestroyOnLoad(this.gameObject);
    }

    private void FixedUpdate()
    {
        memoryReserved = GC.GetTotalMemory(false);
        dataLog.WriteLine(memoryReserved);
        timeLog.WriteLine(Time.time - Time.fixedDeltaTime);
    }

    private void OnApplicationQuit()
    {
        dataLog.Close();
        dataLog.Close();
    }

}

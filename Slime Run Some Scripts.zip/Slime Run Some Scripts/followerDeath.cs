using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class followerDeath : MonoBehaviour
{
    [SerializeField]
    private int numFoll, counter;
    public static UnityAction<int, int> sendInfo = delegate { };
    public UnityEvent byebye;

    public void setBoth(int nF, int c) //Envia esta informacion tanto al behaviour como al manager de followers para tener en ambas la misma informacion
    {
        numFoll = nF;
        counter = c;
    }

    public void Ded()
    {
        sendInfo(counter, numFoll);
        byebye.Invoke();
    }

}
